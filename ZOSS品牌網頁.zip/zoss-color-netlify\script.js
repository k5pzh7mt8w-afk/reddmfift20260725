﻿const header = document.querySelector('[data-header]');
const drawer = document.getElementById('drawer');
const menuBtn = document.getElementById('menuBtn');
const drawerClose = document.getElementById('drawerClose');
const musicBtn = document.getElementById('musicBtn');
const bottomMusicBtn = document.getElementById('bottomMusicBtn');
const bgm = document.getElementById('bgm');
const shareBtn = document.getElementById('shareBtn');
const bottomShareBtn = document.getElementById('bottomShareBtn');
const toTopBtn = document.getElementById('toTopBtn');
const toast = document.getElementById('toast');

const setHeader = () => {
  header.classList.toggle('is-scrolled', window.scrollY > 24);
};

const setDrawer = (open) => {
  drawer.classList.toggle('is-open', open);
  drawer.setAttribute('aria-hidden', String(!open));
  menuBtn.setAttribute('aria-expanded', String(open));
  document.body.style.overflow = open ? 'hidden' : '';
};

window.addEventListener('scroll', setHeader, { passive: true });
setHeader();

menuBtn.addEventListener('click', () => setDrawer(true));
drawerClose.addEventListener('click', () => setDrawer(false));
drawer.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => setDrawer(false)));

const toggleMusic = async () => {
  try {
    if (bgm.paused) {
      await bgm.play();
      setMusicState(true);
    } else {
      bgm.pause();
      setMusicState(false);
    }
  } catch {
    showToast('瀏覽器已阻擋自動播放');
  }
};

const shareSite = async () => {
  const shareData = {
    title: document.title,
    text: 'ZOSS Color 中區品牌頁',
    url: location.href
  };

  try {
    if (navigator.share) {
      await navigator.share(shareData);
    } else {
      await navigator.clipboard.writeText(location.href);
      showToast('已複製連結');
    }
  } catch {
    await navigator.clipboard.writeText(location.href);
    showToast('已複製連結');
  }
};

musicBtn.addEventListener('click', toggleMusic);
bottomMusicBtn.addEventListener('click', toggleMusic);
shareBtn.addEventListener('click', shareSite);
bottomShareBtn.addEventListener('click', shareSite);
toTopBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

function setMusicState(isPlaying) {
  musicBtn.classList.toggle('is-playing', isPlaying);
  bottomMusicBtn.classList.toggle('is-playing', isPlaying);
  bottomMusicBtn.textContent = isPlaying ? '暫停' : '音樂';
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('is-visible');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('is-visible'), 1800);
}
